# BetterAudioPlaylist
Simple code for making an HTML5 audio playlist. 

<h3><a href="https://techtube.github.io/BetterAudioPlaylist/">Demo</a></h3> <h3><a href="https://github.com/TechTube/BetterAudioPlaylist/archive/master.zip">Download</a></h3>  <h3><a href="https://www.youtube.com/watch?v=PZuvCpx5lKY">Installation instructions</a></h3> 
